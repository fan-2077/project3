import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
import matplotlib.colors as mcolors
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px


# ==================== 1. 数据准备 ====================
# 加载鸢尾花数据集
iris = load_iris()
X = iris.data  # 所有特征 [sepal length, sepal width, petal length, petal width]
y = iris.target

# 选择指定的特征和类别
# 使用特征：Sepal Width (index1), Petal Length (index2), Petal Width (index3)
feature_indices = [1, 2, 3]  # Sepal Width, Petal Length, Petal Width
feature_names = [iris.feature_names[i] for i in feature_indices]
X_selected = X[:, feature_indices]

# 只选择类别0(Setosa)和类别2(Virginica)
class_mask = (y == 0) | (y == 2)
X_filtered = X_selected[class_mask]
y_filtered = y[class_mask]

# 将类别2映射为1（二分类问题）
y_binary = np.where(y_filtered == 2, 1, 0)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(
    X_filtered, y_binary, test_size=0.3, random_state=42, stratify=y_binary
)

# 颜色编码（与文档保持一致）
class_colors = ['yellow', 'blue']  # Setosa: 黄色, Virginica: 蓝色
class_names = ['Setosa', 'Virginica']


# ==================== 2. 定义分类器 ====================
classifiers = {
    'Logistic Regression': LogisticRegression(
        max_iter=200,
        random_state=42
    ),
    'SVM (RBF Kernel)': SVC(
        kernel='rbf',
        probability=True,
        random_state=42,
        gamma='scale'
    ),
    'Decision Tree': DecisionTreeClassifier(
        max_depth=4,
        random_state=42
    ),
    'K-Nearest Neighbors': KNeighborsClassifier(
        n_neighbors=5
    ),
    'Random Forest': RandomForestClassifier(
        n_estimators=100,
        max_depth=4,
        random_state=42
    )
}


# ==================== 3. 创建3D网格用于可视化 ====================
# 创建3D网格点
h = 0.2  # 网格步长
x_min, x_max = X_filtered[:, 0].min() - 1, X_filtered[:, 0].max() + 1
y_min, y_max = X_filtered[:, 1].min() - 1, X_filtered[:, 1].max() + 1
z_min, z_max = X_filtered[:, 2].min() - 1, X_filtered[:, 2].max() + 1

xx, yy, zz = np.meshgrid(
    np.arange(x_min, x_max, h),
    np.arange(y_min, y_max, h),
    np.arange(z_min, z_max, h)
)


# ==================== 4. 训练所有分类器 ====================
# 先训练所有分类器，供任务2和任务3使用
trained_classifiers = {}
for clf_name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    trained_classifiers[clf_name] = clf


# ==================== 任务2：3D决策边界可视化 ====================
print("正在生成任务2：3D决策边界可视化...")

# 使用Plotly创建交互式3D图
fig_boundary = make_subplots(
    rows=2, cols=3,
    subplot_titles=list(classifiers.keys()) + ['Original Data'],
    specs=[[{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}],
           [{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}]],
    vertical_spacing=0.1,
    horizontal_spacing=0.05
)

# 为每个分类器创建决策边界可视化
for idx, (clf_name, clf) in enumerate(trained_classifiers.items()):
    # 计算准确率
    train_acc = clf.score(X_train, y_train)
    test_acc = clf.score(X_test, y_test)
    
    # 预测网格点的类别（用于3D决策边界）
    grid_points = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
    Z = clf.predict(grid_points)
    Z = Z.reshape(xx.shape)
    
    # 获取子图位置
    row = idx // 3 + 1
    col = idx % 3 + 1
    
    # 添加决策边界（透明度较低）
    fig_boundary.add_trace(
        go.Volume(
            x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
            value=Z.ravel(),
            isomin=0.5,
            isomax=0.5,
            opacity=0.1,
            surface_count=1,
            colorscale=[[0, 'yellow'], [1, 'blue']],
            showscale=False,
            name=f'{clf_name} Boundary'
        ),
        row=row, col=col
    )
    
    # 添加训练数据点
    for class_idx, color in enumerate(class_colors):
        class_mask_train = (y_train == class_idx)
        fig_boundary.add_trace(
            go.Scatter3d(
                x=X_train[class_mask_train, 0],
                y=X_train[class_mask_train, 1],
                z=X_train[class_mask_train, 2],
                mode='markers',
                marker=dict(
                    size=6,
                    color=color,
                    opacity=0.8,
                    line=dict(color='black', width=1)
                ),
                name=f'{class_names[class_idx]} (Train)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
    
    # 添加测试数据点（不同的标记）
    for class_idx, color in enumerate(class_colors):
        class_mask_test = (y_test == class_idx)
        fig_boundary.add_trace(
            go.Scatter3d(
                x=X_test[class_mask_test, 0],
                y=X_test[class_mask_test, 1],
                z=X_test[class_mask_test, 2],
                mode='markers',
                marker=dict(
                    size=6,
                    color=color,
                    opacity=0.8,
                    symbol='diamond',
                    line=dict(color='black', width=1)
                ),
                name=f'{class_names[class_idx]} (Test)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
    
    # 更新子图标题和布局
    fig_boundary.update_scenes(
        dict(
            xaxis_title=feature_names[0],
            yaxis_title=feature_names[1],
            zaxis_title=feature_names[2],
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        row=row, col=col
    )
    
    # 更新子图标题显示准确率
    fig_boundary.layout.annotations[idx].update(text=f'{clf_name}<br>Train: {train_acc:.3f} | Test: {test_acc:.3f}')

# 添加原始数据分布子图
row, col = 2, 3
for class_idx, color in enumerate(class_colors):
    class_mask_original = (y_binary == class_idx)
    fig_boundary.add_trace(
        go.Scatter3d(
            x=X_filtered[class_mask_original, 0],
            y=X_filtered[class_mask_original, 1],
            z=X_filtered[class_mask_original, 2],
            mode='markers',
            marker=dict(
                size=6,
                color=color,
                opacity=0.8,
                line=dict(color='black', width=1)
            ),
            name=f'{class_names[class_idx]} (Original)',
            showlegend=False
        ),
        row=row, col=col
    )

fig_boundary.update_scenes(
    dict(
        xaxis_title=feature_names[0],
        yaxis_title=feature_names[1],
        zaxis_title=feature_names[2],
        camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
    ),
    row=row, col=col
)

# 更新整体布局
fig_boundary.update_layout(
    title_text="任务2：3D决策边界 - 二分类 (Setosa vs Virginica)<br>特征: Sepal Width, Petal Length, Petal Width",
    title_x=0.5,
    title_y=0.97,
    title_font=dict(size=20),
    height=1000,
    width=1400,
    legend=dict(yanchor="top", y=0.99, xanchor="left", x=-0.15)
)


# ==================== 任务3：3D概率图可视化 ====================
print("正在生成任务3：3D概率图可视化...")

# 创建任务3的概率图
fig_probability = make_subplots(
    rows=2, cols=3,
    subplot_titles=[f'{name} Probability' for name in classifiers.keys()] + ['Probability Legend'],
    specs=[[{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}],
           [{'type': 'scene'}, {'type': 'scene'}, {'type': 'xy'}]],  # 将最后一个改为'xy'类型
    vertical_spacing=0.1,
    horizontal_spacing=0.05
)

# 为每个分类器创建概率图
for idx, (clf_name, clf) in enumerate(trained_classifiers.items()):
    row = idx // 3 + 1
    col = idx % 3 + 1
    
    # 预测网格点的概率
    grid_points = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
    probabilities = clf.predict_proba(grid_points)[:, 1]  # P(Virginica)
    prob_volume = probabilities.reshape(xx.shape)
    
    # 添加多个概率等值面
    probability_levels = [0.2, 0.5, 0.8]  # 低、中、高概率水平
    
    for i, level in enumerate(probability_levels):
        opacity = 0.2 + i * 0.2  # 概率越高，透明度越低
        
        fig_probability.add_trace(
            go.Isosurface(
                x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
                value=prob_volume.ravel(),
                isomin=level - 0.1,
                isomax=level + 0.1,
                opacity=opacity,
                surface_count=1,
                colorscale='Blues',
                caps=dict(x_show=False, y_show=False),
                name=f'P={level}',
                showscale=(idx == 0),
                colorbar=dict(title='P(Virginica)') if idx == 0 else None
            ),
            row=row, col=col
        )
    
    # 添加数据点，按实际概率值着色
    train_probs = clf.predict_proba(X_train)[:, 1]
    test_probs = clf.predict_proba(X_test)[:, 1]
    
    # 训练数据点
    fig_probability.add_trace(
        go.Scatter3d(
            x=X_train[:, 0], y=X_train[:, 1], z=X_train[:, 2],
            mode='markers',
            marker=dict(
                size=6,
                color=train_probs,
                colorscale='RdYlBu_r',  # 红蓝渐变色
                cmin=0, cmax=1,
                opacity=0.8,
                line=dict(color='black', width=1),
                colorbar=dict(title='Probability') if idx == 4 else None
            ),
            name='Train Points',
            showlegend=(idx == 0)
        ),
        row=row, col=col
    )
    
    # 测试数据点（菱形标记）
    fig_probability.add_trace(
        go.Scatter3d(
            x=X_test[:, 0], y=X_test[:, 1], z=X_test[:, 2],
            mode='markers',
            marker=dict(
                size=6,
                color=test_probs,
                colorscale='RdYlBu_r',
                cmin=0, cmax=1,
                opacity=0.8,
                symbol='diamond',
                line=dict(color='black', width=1)
            ),
            name='Test Points',
            showlegend=(idx == 0)
        ),
        row=row, col=col
    )
    
    # 更新场景设置
    fig_probability.update_scenes(
        dict(
            xaxis_title=feature_names[0],
            yaxis_title=feature_names[1],
            zaxis_title=feature_names[2],
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        row=row, col=col
    )

# 最后一个子图作为图例说明
row, col = 2, 3
# 添加颜色条图例（使用2D散点图）
fig_probability.add_trace(
    go.Scatter(
        x=[None], y=[None],
        mode='markers',
        marker=dict(
            size=15,
            color=[0, 0.5, 1],  # 示例颜色值
            colorscale='RdYlBu_r',
            showscale=True,
            colorbar=dict(
                title='P(Virginica)',
                x=1.1,
                len=0.8
            )
        ),
        name='Probability Color Scale'
    ),
    row=row, col=col
)

# 添加图例说明文本 - 使用2D注释
fig_probability.add_annotation(
    dict(
        text="<b>Probability Map Legend:</b><br>• Blue surfaces: Probability levels<br>• Colored points: Prediction confidence<br>• Red→Blue: Setosa→Virginica probability",
        xref=f"x{6 if col == 3 else col}",  # 动态引用x轴
        yref=f"y{6 if col == 3 else col}",  # 动态引用y轴
        x=0.5, y=0.5,
        xanchor='center',
        yanchor='middle',
        showarrow=False,
        font=dict(size=12),
        bgcolor='white',
        bordercolor='black',
        borderwidth=1
    ),
    row=row, col=col
)

# 更新2D子图的布局
fig_probability.update_xaxes(
    visible=False, 
    showticklabels=False,
    row=row, col=col
)
fig_probability.update_yaxes(
    visible=False, 
    showticklabels=False,
    row=row, col=col
)

# 更新场景设置（只针对3D子图）
for i in range(5):  # 前5个是3D子图
    row = i // 3 + 1
    col = i % 3 + 1
    fig_probability.update_scenes(
        dict(
            xaxis_title=feature_names[0],
            yaxis_title=feature_names[1],
            zaxis_title=feature_names[2],
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        row=row, col=col
    )

# 更新整体布局
fig_probability.update_layout(
    title_text="任务3：3D概率图 - 分类置信度可视化",
    title_x=0.5,
    height=1000,
    width=1400,
    legend=dict(yanchor="top", y=0.99, xanchor="left", x=-0.15)
)


# ==================== 显示所有图表和性能汇总 ====================
print("显示任务2：3D决策边界图...")
fig_boundary.show()

print("显示任务3：3D概率图...")
fig_probability.show()


# ==================== 性能汇总 ====================
print("=" * 80)
print("任务2 & 任务3性能汇总")
print("=" * 80)
print(f"分类类别: {class_names}")
print(f"使用特征: {feature_names}")
print("-" * 80)
print(f"{'分类器':<25} {'训练准确率':<15} {'测试准确率':<15}")
print("-" * 80)

for clf_name, clf in trained_classifiers.items():
    train_acc = clf.score(X_train, y_train)
    test_acc = clf.score(X_test, y_test)
    print(f"{clf_name:<25} {train_acc:.4f}            {test_acc:.4f}")

print("=" * 80)
print("数据集信息:")
print(f"- 总样本数: {len(X_filtered)}")
print(f"- 训练样本数: {len(X_train)}")
print(f"- 测试样本数: {len(X_test)}")
print(f"- 使用特征: {feature_names}")
print("=" * 80)

print("\n任务2和任务3已完成")
print("• 任务2: 3D决策边界可视化 - 显示硬分类边界")
print("• 任务3: 3D概率图可视化 - 显示分类置信度")
fig_boundary.write_html("task2_result.html")
fig_probability.write_html("task3_result.html")

print("结果已保存为：")
print("1. task2_result.html - 3D决策边界")
print("2. task3_result.html - 3D概率图")
print("\n引用方法：")
print("- 在浏览器中打开HTML文件查看交互式结果")
print("- 或将文件路径提供给需要查看的人")