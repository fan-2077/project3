import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from sklearn.decomposition import PCA
import plotly.express as px

# ==================== 1. 数据准备（使用全部4个特征） ====================
print("正在准备数据...")

iris = load_iris()
X = iris.data  # 使用全部4个特征
y = iris.target

feature_names = iris.feature_names
class_names = ['Setosa', 'Versicolor', 'Virginica']

print(f"使用的特征: {feature_names}")
print(f"特征维度: {X.shape}")

# 数据标准化（仅用于可视化，训练时使用原始数据）
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分数据集（使用原始数据）
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

print(f"训练集形状: {X_train.shape}, 测试集形状: {X_test.shape}")

# ==================== 2. 定义分类器 ====================
classifiers = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'SVM (RBF Kernel)': SVC(kernel='rbf', probability=True, random_state=42),
    'Decision Tree': DecisionTreeClassifier(max_depth=4, random_state=42),
    'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
    'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42)
}

# ==================== 3. 交叉验证评估性能 ====================
print("进行交叉验证评估...")
cv_results = {}

# 设置交叉验证
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

for clf_name, clf in classifiers.items():
    print(f"评估 {clf_name}...")
    
    # 交叉验证
    cv_scores = cross_val_score(clf, X, y, cv=cv, scoring='accuracy')
    
    cv_results[clf_name] = {
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std(),
        'cv_scores': cv_scores
    }

# ==================== 4. 训练所有分类器（使用原始数据） ====================
print("训练分类器...")
classifier_performance = {}
trained_classifiers = {}

for clf_name, clf in classifiers.items():
    print(f"训练 {clf_name}...")
    
    # 使用原始数据训练
    clf.fit(X_train, y_train)
    
    # 评估性能
    train_acc = accuracy_score(y_train, clf.predict(X_train))
    test_acc = accuracy_score(y_test, clf.predict(X_test))
    
    classifier_performance[clf_name] = {
        'train_accuracy': train_acc,
        'test_accuracy': test_acc,
        'cv_mean': cv_results[clf_name]['cv_mean'],
        'cv_std': cv_results[clf_name]['cv_std'],
        'classifier': clf
    }
    trained_classifiers[clf_name] = clf

# ==================== 5. PCA降维仅用于可视化 ====================
print("使用PCA将4维特征降维到3维用于可视化...")
pca = PCA(n_components=3)
X_pca = pca.fit_transform(X_scaled)  # 仅用于可视化
X_train_pca = pca.transform(scaler.transform(X_train))
X_test_pca = pca.transform(scaler.transform(X_test))

print(f"PCA解释方差比: {pca.explained_variance_ratio_}")
print(f"累计解释方差: {np.sum(pca.explained_variance_ratio_):.4f}")

# ==================== 6. 改进的3D决策边界可视化 ====================
print("正在生成改进的3D决策边界可视化...")

# 创建3D网格（在PCA空间）
h = 0.3
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
z_min, z_max = X_pca[:, 2].min() - 1, X_pca[:, 2].max() + 1

xx, yy, zz = np.meshgrid(
    np.arange(x_min, x_max, h),
    np.arange(y_min, y_max, h),
    np.arange(z_min, z_max, h)
)

# 创建决策边界可视化
fig_boundary = make_subplots(
    rows=2, cols=3,
    subplot_titles=list(classifiers.keys()) + ['Original Data (PCA)'],
    specs=[[{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}],
           [{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}]],
    vertical_spacing=0.1,
    horizontal_spacing=0.05
)

# 为每个分类器创建决策边界可视化
for idx, (clf_name, clf) in enumerate(trained_classifiers.items()):
    perf = classifier_performance[clf_name]
    
    # 预测网格点的类别（关键改进：在原始空间预测）
    grid_points_pca = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
    
    # 将PCA网格点逆变换回原始空间进行预测
    grid_points_scaled = pca.inverse_transform(grid_points_pca)
    grid_points_original = scaler.inverse_transform(grid_points_scaled)
    
    # 在原始空间进行预测
    Z = clf.predict(grid_points_original)
    Z = Z.reshape(xx.shape)
    
    # 获取子图位置
    row = idx // 3 + 1
    col = idx % 3 + 1
    
    # 添加决策边界
    fig_boundary.add_trace(
        go.Volume(
            x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
            value=Z.ravel(),
            isomin=0, isomax=2,
            opacity=0.1,
            surface_count=3,
            colorscale=[[0, 'red'], [0.5, 'green'], [1, 'blue']],
            showscale=False,
            name=f'{clf_name} Boundary'
        ),
        row=row, col=col
    )
    
    # 添加训练数据点
    colors = ['red', 'green', 'blue']
    for class_idx, color in enumerate(colors):
        mask = (y_train == class_idx)
        fig_boundary.add_trace(
            go.Scatter3d(
                x=X_train_pca[mask, 0],
                y=X_train_pca[mask, 1],
                z=X_train_pca[mask, 2],
                mode='markers',
                marker=dict(size=6, color=color, opacity=0.8, line=dict(color='black', width=1)),
                name=f'{class_names[class_idx]} (Train)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
    
    # 添加测试数据点（菱形标记）
    for class_idx, color in enumerate(colors):
        mask = (y_test == class_idx)
        fig_boundary.add_trace(
            go.Scatter3d(
                x=X_test_pca[mask, 0],
                y=X_test_pca[mask, 1],
                z=X_test_pca[mask, 2],
                mode='markers',
                marker=dict(size=6, color=color, opacity=0.8, symbol='diamond', 
                           line=dict(color='black', width=1)),
                name=f'{class_names[class_idx]} (Test)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
    
    # 更新子图标题显示性能（包含交叉验证结果）
    fig_boundary.layout.annotations[idx].update(
        text=f'{clf_name}<br>Train: {perf["train_accuracy"]:.3f} | Test: {perf["test_accuracy"]:.3f}<br>CV: {perf["cv_mean"]:.3f} ± {perf["cv_std"]:.3f}'
    )
    
    # 更新场景设置
    fig_boundary.update_scenes(
        dict(
            xaxis_title='PC1',
            yaxis_title='PC2', 
            zaxis_title='PC3',
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        row=row, col=col
    )

# 添加原始数据分布子图
row, col = 2, 3
colors = ['red', 'green', 'blue']
for class_idx, color in enumerate(colors):
    mask = (y == class_idx)
    fig_boundary.add_trace(
        go.Scatter3d(
            x=X_pca[mask, 0],
            y=X_pca[mask, 1], 
            z=X_pca[mask, 2],
            mode='markers',
            marker=dict(size=6, color=color, opacity=0.8, line=dict(color='black', width=1)),
            name=f'{class_names[class_idx]} (All)',
            showlegend=False
        ),
        row=row, col=col
    )

fig_boundary.update_scenes(
    dict(
        xaxis_title='PC1',
        yaxis_title='PC2',
        zaxis_title='PC3',
        camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
    ),
    row=row, col=col
)

# 更新整体布局
fig_boundary.update_layout(
    title_text="在原始空间训练，仅用PCA可视化4特征3分类问题",
    title_x=0.5,
    title_y=0.99,
    title_font=dict(size=16),
    height=1000,
    width=1400,
    legend=dict(yanchor="top", y=0.99, xanchor="left", x=-0.1)
)

# ==================== 7. 性能对比图（包含交叉验证） ====================
classifier_names = list(classifiers.keys())
train_accs = [classifier_performance[name]['train_accuracy'] for name in classifier_names]
test_accs = [classifier_performance[name]['test_accuracy'] for name in classifier_names]
cv_means = [classifier_performance[name]['cv_mean'] for name in classifier_names]
cv_stds = [classifier_performance[name]['cv_std'] for name in classifier_names]

# 创建性能对比图
fig_performance = go.Figure()

# 添加柱状图
fig_performance.add_trace(go.Bar(
    name='Training Accuracy', 
    x=classifier_names, 
    y=train_accs,
    marker_color='lightblue'
))

fig_performance.add_trace(go.Bar(
    name='Test Accuracy', 
    x=classifier_names, 
    y=test_accs,
    marker_color='lightcoral'
))

# 添加交叉验证结果（带误差线）
fig_performance.add_trace(go.Scatter(
    name='CV Mean ± Std',
    x=classifier_names,
    y=cv_means,
    error_y=dict(type='data', array=cv_stds, visible=True),
    mode='markers',
    marker=dict(size=10, color='black'),
    line=dict(color='black')
))

fig_performance.update_layout(
    title_text="分类器性能对比（包含5折交叉验证）",
    title_x=0.5,
    xaxis_title="Classifier",
    yaxis_title="Accuracy",
    barmode='group'
)

# ==================== 8. 交叉验证详细结果 ====================
print("\n" + "="*80)
print("交叉验证详细结果")
print("="*80)

cv_details = []
for clf_name in classifier_names:
    cv_scores = cv_results[clf_name]['cv_scores']
    for fold, score in enumerate(cv_scores):
        cv_details.append({
            'Classifier': clf_name,
            'Fold': fold + 1,
            'Accuracy': score
        })

cv_df = pd.DataFrame(cv_details)

# 创建交叉验证详细结果图
fig_cv_detail = px.box(
    cv_df, 
    x='Classifier', 
    y='Accuracy', 
    color='Classifier',
    title="5折交叉验证详细结果"
)
fig_cv_detail.update_layout(title_x=0.5)

# ==================== 9. 特征重要性分析 ====================
print("\n特征重要性分析...")

# 分析随机森林的特征重要性
rf_clf = trained_classifiers['Random Forest']
feature_importance = rf_clf.feature_importances_

# 创建特征重要性图
fig_feature_importance = go.Figure()
fig_feature_importance.add_trace(go.Bar(
    x=feature_names,
    y=feature_importance,
    marker_color='lightgreen'
))

fig_feature_importance.update_layout(
    title_text="随机森林特征重要性（4个特征）",
    title_x=0.5,
    xaxis_title="Features",
    yaxis_title="Importance"
)

# ==================== 10. 3D概率图可视化（修复颜色问题） ====================
print("\n正在生成3D概率图可视化...")

# 创建概率图可视化
fig_probability = make_subplots(
    rows=2, cols=3,
    subplot_titles=[f'{name} - 类别概率分布' for name in classifiers.keys()] + ['概率图说明'],
    specs=[[{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}],
           [{'type': 'scene'}, {'type': 'scene'}, {'type': 'scene'}]],
    vertical_spacing=0.1,
    horizontal_spacing=0.05
)

# 定义有效的颜色映射
color_mapping = {
    'red': {'light': 'lightcoral', 'dark': 'red'},
    'green': {'light': 'lightgreen', 'dark': 'green'}, 
    'blue': {'light': 'lightblue', 'dark': 'blue'}
}

# 为每个分类器创建概率图
for idx, (clf_name, clf) in enumerate(trained_classifiers.items()):
    # 预测网格点的概率（关键改进：在原始空间预测概率）
    grid_points_pca = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
    
    # 将PCA网格点逆变换回原始空间进行概率预测
    grid_points_scaled = pca.inverse_transform(grid_points_pca)
    grid_points_original = scaler.inverse_transform(grid_points_scaled)
    
    # 在原始空间进行概率预测
    probabilities = clf.predict_proba(grid_points_original)
    
    # 获取子图位置
    row = idx // 3 + 1
    col = idx % 3 + 1
    
    # 为每个类别创建概率等值面
    for class_idx, (class_name, color) in enumerate(zip(class_names, ['red', 'green', 'blue'])):
        prob_class = probabilities[:, class_idx].reshape(xx.shape)
        
        # 使用有效的颜色名称
        light_color = color_mapping[color]['light']
        dark_color = color_mapping[color]['dark']
        
        # 添加概率等值面（显示概率>0.5的区域）
        fig_probability.add_trace(
            go.Isosurface(
                x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
                value=prob_class.ravel(),
                isomin=0.5,  # 显示概率大于0.5的区域
                isomax=1.0,
                surface_count=3,  # 显示3个等值面
                opacity=0.3,
                colorscale=[[0, light_color], [1, dark_color]],  # 修复颜色问题
                caps=dict(x_show=False, y_show=False, z_show=False),
                name=f'{class_name}概率',
                showlegend=(idx == 0)  # 只在第一个子图显示图例
            ),
            row=row, col=col
        )
    
    # 添加数据点（显示真实标签）
    colors = ['red', 'green', 'blue']
    for class_idx, color in enumerate(colors):
        mask_train = (y_train == class_idx)
        mask_test = (y_test == class_idx)
        
        # 训练数据点
        fig_probability.add_trace(
            go.Scatter3d(
                x=X_train_pca[mask_train, 0],
                y=X_train_pca[mask_train, 1],
                z=X_train_pca[mask_train, 2],
                mode='markers',
                marker=dict(size=6, color=color, opacity=0.8, 
                           line=dict(color='black', width=1)),
                name=f'{class_names[class_idx]} (Train)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
        
        # 测试数据点（菱形标记）
        fig_probability.add_trace(
            go.Scatter3d(
                x=X_test_pca[mask_test, 0],
                y=X_test_pca[mask_test, 1],
                z=X_test_pca[mask_test, 2],
                mode='markers',
                marker=dict(size=6, color=color, opacity=0.8, symbol='diamond',
                           line=dict(color='black', width=1)),
                name=f'{class_names[class_idx]} (Test)',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
    
    # 更新子图场景设置
    fig_probability.update_scenes(
        dict(
            xaxis_title='PC1',
            yaxis_title='PC2', 
            zaxis_title='PC3',
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        row=row, col=col
    )

# 添加概率图说明子图
row, col = 2, 3
# 使用有效的颜色名称创建说明
fig_probability.add_trace(
    go.Scatter3d(
        x=[0], y=[0], z=[0],
        mode='text',
        text=['概率图说明:<br>• 彩色等值面显示各类别概率>0.5的区域<br>• 透明度表示概率大小<br>• 不同颜色对应不同类别'],
        textposition='middle center',
        showlegend=False
    ),
    row=row, col=col
)

fig_probability.update_scenes(
    dict(
        xaxis_title='PC1',
        yaxis_title='PC2',
        zaxis_title='PC3',
        camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
    ),
    row=row, col=col
)

# 更新整体布局
fig_probability.update_layout(
    title_text="3D概率图可视化 - 各类别概率分布（概率>0.5的区域）",
    title_x=0.5,
    title_font=dict(size=16),
    height=1000,
    width=1400,
    legend=dict(yanchor="top", y=0.99, xanchor="left", x=-0.15)
)

# ==================== 11. 单个分类器详细概率分析 ====================
print("生成单个分类器详细概率分析...")

# 选择Random Forest作为示例进行详细概率分析
example_clf_name = 'Random Forest'  # 明确定义变量
example_clf = trained_classifiers[example_clf_name]

# 创建详细概率分析图
fig_detailed_prob = make_subplots(
    rows=2, cols=2,
    subplot_titles=[
        f'{example_clf_name} - Setosa概率', 
        f'{example_clf_name} - Versicolor概率',
        f'{example_clf_name} - Virginica概率',
        '最大概率类别'
    ],
    specs=[[{'type': 'scene'}, {'type': 'scene'}],
           [{'type': 'scene'}, {'type': 'scene'}]]
)

# 计算概率
grid_points_pca = np.c_[xx.ravel(), yy.ravel(), zz.ravel()]
grid_points_scaled = pca.inverse_transform(grid_points_pca)
grid_points_original = scaler.inverse_transform(grid_points_scaled)
probabilities = example_clf.predict_proba(grid_points_original)

# 为每个类别创建概率图
for class_idx in range(3):
    prob_map = probabilities[:, class_idx].reshape(xx.shape)
    
    # 添加概率体积图
    fig_detailed_prob.add_trace(
        go.Volume(
            x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
            value=prob_map.ravel(),
            isomin=0.1, isomax=1.0,
            opacity=0.2,
            surface_count=5,
            colorscale='Viridis',
            colorbar=dict(title='概率', x=1.0 if class_idx == 1 else None),
            name=f'{class_names[class_idx]}概率'
        ),
        row=class_idx//2 + 1, col=class_idx%2 + 1
    )
    
    # 添加数据点
    for data_class_idx, color in enumerate(['red', 'green', 'blue']):
        mask = (y == data_class_idx)
        fig_detailed_prob.add_trace(
            go.Scatter3d(
                x=X_pca[mask, 0], y=X_pca[mask, 1], z=X_pca[mask, 2],
                mode='markers',
                marker=dict(size=5, color=color, opacity=0.7),
                name=class_names[data_class_idx],
                showlegend=(class_idx == 0)
            ),
            row=class_idx//2 + 1, col=class_idx%2 + 1
        )

# 添加最大概率类别图（决策边界）
max_prob_class = np.argmax(probabilities, axis=1).reshape(xx.shape)
fig_detailed_prob.add_trace(
    go.Volume(
        x=xx.ravel(), y=yy.ravel(), z=zz.ravel(),
        value=max_prob_class.ravel(),
        isomin=0, isomax=2,
        opacity=0.3,
        surface_count=3,
        colorscale=[[0, 'red'], [0.5, 'green'], [1, 'blue']],
        colorbar=dict(title='类别', x=1.0),
        name='最大概率类别'
    ),
    row=2, col=2
)

# 添加数据点到决策边界图
for class_idx, color in enumerate(['red', 'green', 'blue']):
    mask = (y == class_idx)
    fig_detailed_prob.add_trace(
        go.Scatter3d(
            x=X_pca[mask, 0], y=X_pca[mask, 1], z=X_pca[mask, 2],
            mode='markers',
            marker=dict(size=5, color=color, opacity=0.7),
            name=class_names[class_idx],
            showlegend=False
        ),
        row=2, col=2
    )

# 更新场景设置
for i in [1, 2]:
    for j in [1, 2]:
        fig_detailed_prob.update_scenes(
            dict(
                xaxis_title='PC1', yaxis_title='PC2', zaxis_title='PC3',
                camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
            ),
            row=i, col=j
        )

# 修复：使用正确的变量名
fig_detailed_prob.update_layout(
    title_text=f"{example_clf_name}详细概率分析",  # 使用明确定义的变量
    title_x=0.5,
    height=800,
    width=1000
)

# ==================== 12. 结果显示和保存 ====================
print("\n" + "="*80)
print("改进版：在原始空间训练 + PCA可视化 + 交叉验证 性能汇总")
print("="*80)
print(f"{'Classifier':<25} {'Train Acc':<10} {'Test Acc':<10} {'CV Mean':<10} {'CV Std':<10}")
print("-"*80)

for clf_name in classifier_names:
    perf = classifier_performance[clf_name]
    print(f"{clf_name:<25} {perf['train_accuracy']:.4f}      {perf['test_accuracy']:.4f}      {perf['cv_mean']:.4f}      {perf['cv_std']:.4f}")

print("="*80)
print("数据集信息:")
print(f"- 总样本数: {len(X)}")
print(f"- 训练样本数: {len(X_train)}")
print(f"- 测试样本数: {len(X_test)}")
print(f"- 使用特征: {feature_names}")
print(f"- PCA累计解释方差: {np.sum(pca.explained_variance_ratio_):.4f}")
print("="*80)

# 显示图表
print("显示改进版3D决策边界图...")
fig_boundary.show()

print("显示概率图...")
fig_probability.show()
fig_detailed_prob.show()

print("显示性能对比图...")
fig_performance.show()

print("显示交叉验证详细结果...")
fig_cv_detail.show()

print("显示特征重要性...")
fig_feature_importance.show()

# 保存HTML文件
print("保存结果文件...")
fig_boundary.write_html("improved_task4_decision_boundary.html")
fig_performance.write_html("improved_task4_performance.html")
fig_cv_detail.write_html("improved_task4_cv_details.html")
fig_feature_importance.write_html("improved_task4_feature_importance.html")
fig_probability.write_html("improved_task4_probability_maps.html")
fig_detailed_prob.write_html("improved_task4_detailed_probability.html")

# 保存交叉验证结果到CSV
cv_df.to_csv("improved_task4_cv_results.csv", index=False)

print("\n改进版Task4已完成！")
print("✓ 在原始特征空间训练模型")
print("✓ 仅使用PCA进行可视化")
print("✓ 5折交叉验证评估性能")
print("✓ 特征重要性分析")
print("\n主要改进:")
print("1. 训练和预测在原始特征空间进行，避免标准化带来的数据不一致")
print("2. PCA仅用于可视化，不参与模型训练")
print("3. 交叉验证提供更可靠的性能评估")
print("4. 特征重要性分析帮助理解模型决策")

print("\n结果文件:")
print("1. improved_task4_decision_boundary.html - 3D决策边界")
print("2. improved_task4_performance.html - 性能对比")
print("3. improved_task4_cv_details.html - 交叉验证详情")
print("4. improved_task4_feature_importance.html - 特征重要性")
print("5. improved_task4_cv_results.csv - 交叉验证数据")

print("\n与Task1对比分析:")
print("通过交叉验证可以更准确地比较4特征和2特征的性能差异")
print("特征重要性分析可以验证哪些特征对分类真正有用")