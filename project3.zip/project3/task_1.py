"""
任务一：可视化不同分类器的结果（汇总概率图）
Task 1: Visualizing Results of Different Classifiers (Summary Probability Map)
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

# ==================== 1. 数据准备 ====================
# Load dataset
iris = load_iris()
X = iris.data[:, 2:]  # 使用后两个特征：Petal Length 和 Petal Width
y = iris.target
feature_names = iris.feature_names[2:]  # ['petal length (cm)', 'petal width (cm)']

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# 类别名称和颜色
class_names = ['Setosa', 'Versicolor', 'Virginica']
class_colors = ['yellow', 'green', 'blue']  # 与参考代码保持一致

# ==================== 2. 定义分类器 ====================
classifiers = {
    'Logistic Regression': LogisticRegression(
        max_iter=200,
        random_state=42,
        multi_class='ovr'
    ),
    'SVM (RBF Kernel)': SVC(
        kernel='rbf',
        probability=True,
        random_state=42,
        gamma='scale'
    ),
    'Decision Tree': DecisionTreeClassifier(
        max_depth=4,
        random_state=42
    ),
    'K-Nearest Neighbors': KNeighborsClassifier(
        n_neighbors=5
    ),
    'Random Forest': RandomForestClassifier(
        n_estimators=100,
        max_depth=4,
        random_state=42
    )
}

# ==================== 3. 创建网格用于可视化 ====================
h = 0.1  # 网格步长
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(
    np.arange(x_min, x_max, h),
    np.arange(y_min, y_max, h)
)
grid_points = np.c_[xx.ravel(), yy.ravel()]

# ==================== 4. 训练所有分类器 ====================
trained_classifiers = {}
for clf_name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    trained_classifiers[clf_name] = clf

# ==================== 5. 决策边界可视化 ====================
print("正在生成决策边界可视化...")

# 创建2×3的子图布局
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
axes = axes.flatten()

# 颜色映射
cmap_background = mcolors.ListedColormap(class_colors)

# 为每个分类器创建决策边界可视化
for idx, (clf_name, clf) in enumerate(trained_classifiers.items()):
    ax = axes[idx]
    
    # 计算准确率
    train_acc = clf.score(X_train, y_train)
    test_acc = clf.score(X_test, y_test)
    
    # 预测网格点的类别
    Z = clf.predict(grid_points)
    Z = Z.reshape(xx.shape)
    
    # 绘制决策区域
    ax.imshow(Z, 
              extent=(xx.min(), xx.max(), yy.min(), yy.max()),
              origin='lower',
              cmap=cmap_background, 
              alpha=0.6,
              aspect='auto')
    
    # 绘制数据点
    scatter = ax.scatter(X[:, 0], X[:, 1], 
                         c=y, 
                         edgecolors='k', 
                         marker='o', 
                         s=50, 
                         cmap=mcolors.ListedColormap(class_colors))
    
    # 设置标题和标签
    ax.set_title(f'{clf_name}\nTrain Acc: {train_acc:.3f} | Test Acc: {test_acc:.3f}', 
                 fontsize=12, fontweight='bold')
    ax.set_xlabel('Petal Length (cm)', fontsize=10)
    ax.set_ylabel('Petal Width (cm)', fontsize=10)
    
    # 设置坐标轴范围
    ax.set_xlim(xx.min(), xx.max())
    ax.set_ylim(yy.min(), yy.max())

# 第6个子图：原始数据分布
ax = axes[5]
scatter = ax.scatter(X[:, 0], X[:, 1], 
                     c=y, 
                     edgecolors='k', 
                     marker='o', 
                     s=50, 
                     cmap=mcolors.ListedColormap(class_colors))

ax.set_title('Original Data Distribution', fontsize=12, fontweight='bold')
ax.set_xlabel('Petal Length (cm)', fontsize=10)
ax.set_ylabel('Petal Width (cm)', fontsize=10)
ax.set_xlim(xx.min(), xx.max())
ax.set_ylim(yy.min(), yy.max())

# 添加图例
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=color, edgecolor='k', label=name) 
                   for color, name in zip(class_colors, class_names)]
ax.legend(handles=legend_elements, loc='lower right', fontsize=10)

# 添加整体标题和调整布局
plt.suptitle('Iris Dataset: Decision Boundaries of Different Classifiers\nFeatures: Petal Length vs Petal Width', 
             fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('task1_classifiers_comparison.png', dpi=300, bbox_inches='tight')
plt.show()

# ==================== 6. 汇总概率图可视化 ====================
print("正在生成汇总概率图...")

# 创建5行4列的大图：5个分类器 × (决策边界 + 3个类别概率)
fig, axes = plt.subplots(5, 4, figsize=(20, 20))

# 为每个分类器创建一行
for row, (clf_name, clf) in enumerate(trained_classifiers.items()):
    print(f"处理 {clf_name} 的概率图...")
    
    # 计算概率
    probabilities = clf.predict_proba(grid_points)
    probabilities = probabilities.reshape(xx.shape[0], xx.shape[1], 3)
    
    # 第一列：决策边界
    Z = clf.predict(grid_points)
    Z = Z.reshape(xx.shape)
    
    ax = axes[row, 0]
    ax.imshow(Z, 
              extent=(xx.min(), xx.max(), yy.min(), yy.max()),
              origin='lower',
              cmap=mcolors.ListedColormap(class_colors), 
              alpha=0.6,
              aspect='auto')
    ax.scatter(X[:, 0], X[:, 1], 
               c=y, 
               edgecolors='k', 
               marker='o', 
               s=30, 
               cmap=mcolors.ListedColormap(class_colors))
    ax.set_title(f'{clf_name}\nDecision Boundary', fontsize=10)
    ax.set_xlabel('Petal Length')
    ax.set_ylabel('Petal Width')
    
    # 第2-4列：每个类别的概率
    for col in range(3):
        ax = axes[row, col + 1]
        class_prob = probabilities[:, :, col]
        
        # 创建渐变色映射
        cmap = mcolors.LinearSegmentedColormap.from_list(
            f'class_{col}_colormap', ['white', class_colors[col]], N=256)
        
        # 绘制概率图
        contour = ax.contourf(xx, yy, class_prob, alpha=0.7, cmap=cmap, levels=15)
        
        # 绘制数据点
        ax.scatter(X[:, 0], X[:, 1], 
                   c=y, 
                   edgecolors='k', 
                   marker='o', 
                   s=30, 
                   cmap=mcolors.ListedColormap(class_colors), 
                   alpha=1)
        
        # 设置标题
        ax.set_title(f'{class_names[col]} Probability', fontsize=10)
        ax.set_xlabel('Petal Length')
        ax.set_ylabel('Petal Width')
        
        # 为每行第一个概率图添加颜色条
        if col == 0:
            from mpl_toolkits.axes_grid1 import make_axes_locatable
            divider = make_axes_locatable(ax)
            cax = divider.append_axes("right", size="5%", pad=0.1)
            plt.colorbar(contour, cax=cax)

# 添加整体标题
plt.suptitle('Comparative Analysis: Decision Boundaries and Probability Maps for All Classifiers\n'
             'Rows: Different Classifiers | Columns: Decision Boundary and Class Probabilities', 
             fontsize=16, fontweight='bold', y=0.95)

plt.tight_layout()
plt.savefig('task1_summary_probability_maps.png', dpi=300, bbox_inches='tight')
plt.show()

# ==================== 7. 性能汇总 ====================
print("=" * 70)
print("Classifier Performance Summary:")
print("=" * 70)
print(f"{'Classifier':<25} {'Train Accuracy':<15} {'Test Accuracy':<15}")
print("-" * 70)

for clf_name, clf in trained_classifiers.items():
    train_acc = clf.score(X_train, y_train)
    test_acc = clf.score(X_test, y_test)
    print(f"{clf_name:<25} {train_acc:.4f}            {test_acc:.4f}")

print("=" * 70)
print("Dataset Information:")
print(f"- Total samples: {len(X)}")
print(f"- Training samples: {len(X_train)}")
print(f"- Test samples: {len(X_test)}")
print(f"- Features: {feature_names[0]}, {feature_names[1]}")
print("=" * 70)

print("\n任务一已完成！生成的文件：")
print("1. task1_classifiers_comparison.png - 决策边界对比图")
print("2. task1_summary_probability_maps.png - 汇总概率图")

print("\n汇总概率图说明：")
print("- 行：5个不同的分类器")
print("- 列1：决策边界可视化")
print("- 列2：Setosa类别的概率分布")
print("- 列3：Versicolor类别的概率分布") 
print("- 列4：Virginica类别的概率分布")
print("- 颜色条：显示概率值（0-1）")